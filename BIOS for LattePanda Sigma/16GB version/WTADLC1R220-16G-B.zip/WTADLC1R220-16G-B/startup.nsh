@echo -off 
for %a run (0 15 1) 
  if exist fs%a:\WTADLC1R220-16G-B then  
     fs%a:  
     cd WTADLC1R220-16G-B 
     cls  
     BIOS.nsh 
  endif  
endfor  
