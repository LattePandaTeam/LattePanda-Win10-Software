@echo -off 
for %a run (0 15 1) 
  if exist fs%a:\LP-BS-7-S70KR310-KF65C-C then  
     fs%a:  
     cd LP-BS-7-S70KR310-KF65C-C 
     cls  
     BIOS.nsh 
  endif  
endfor