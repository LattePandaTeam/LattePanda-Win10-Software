@echo Updating BIOS...... 
mv fpt64.wbf fpt64.efi 
fpt64.efi -f LP-BS-7-S70KR310-KF65C-C.BIN -y
mv fpt64.efi fpt64.wbf 	
@echo Update BIOS done! 
