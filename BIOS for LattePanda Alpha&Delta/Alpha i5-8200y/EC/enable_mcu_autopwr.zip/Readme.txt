This EC firmware controls the MCU power supply according to the system power state:

- Power connected (system off) : MCU is NOT powered
- System running               : MCU is powered
- System in sleep              : MCU is powered
- System shut down             : MCU is NOT powered

Note: The auto power-on feature is disabled by this firmware.
Once the LattePanda is connected to a power source, you must press the power button to turn it on.
