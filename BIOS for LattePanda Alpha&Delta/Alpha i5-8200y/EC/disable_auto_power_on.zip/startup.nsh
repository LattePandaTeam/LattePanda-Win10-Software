@echo -off
for %a run (0 15 1)
  if exist fs%a:\FEC64.NSH then
     fs%a:
     cls
     FEC64.NSH
  endif
endfor
