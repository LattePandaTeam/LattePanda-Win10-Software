﻿BIOS基本信息：

Build Date:	2023/4/26
BIOS name:	LP-BS-7-S70JR120-CN51G-D-UBT-ON_20230426095504.bin
Checksum:	4792
BIOS Message:	LP-BS-7-S70JR120-CN51G-D-UBT-ON BIOS Date: 04/26/2023 09:55:04

描述：
1.去掉固定启动顺序
2.默认上电自启

刷新方法：
1, 刷新BIOS： fpt.efi -bios -f Biosname.bin
2, 刷新BIOS+ME：fpt.efi -f Biosname.bin